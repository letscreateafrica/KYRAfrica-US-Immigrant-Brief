# KnowYourRights Africa

Working static web app: homepage, archive search by keyword/perspective/date, dated editions, policy filters and refresh, WhatsApp sharing, SVG edition posters, text-only mode and print support. October 5 and 7 archive URLs are preserved. October 9 is a limited launch/reference edition with one checked South African government notice; it is not a comprehensive news scan.

The supplied U.S. Immigrant Brief shared-chat snapshot is preserved separately at `/tracker/`. It contains seven prior generated records dated October 4–8, including alternate visual editions. They are labeled historical automated output and are not inserted into current news or verified alerts. Their cited claims have not all been independently rechecked, and original image references are text only. The archive links to the source snapshot and keeps the generated text for provenance. Future daily editions use the saved tracker editorial instructions in `TRACKER-EDITORIAL-INSTRUCTIONS.md` as a research brief, then verify primary sources under `EDITORIAL-WORKFLOW.md` before publication.

## Run and build

Requires Node 18+; no dependencies, installation or API keys.

```
node build.mjs
node serve.mjs
```

Open http://127.0.0.1:4173. Do not open index.html directly as a file: fetch and root-relative routes require HTTP. Deploy the entire dist directory at the domain root, including briefs, archive, posters and data. The server binds loopback only and is for preview, not public hosting.

## Content and evidence

Edit content.json, then build. src contains the app template, styling and interactions. prepare.mjs generates dated HTML with a no-JavaScript reading fallback and compact SVG posters. Dates use ISO YYYY-MM-DD; research status is rendered in Pacific time. Existing archive pages remain untouched. validate.mjs rejects missing citations, duplicate dates and policy alerts missing review fields or an approved official primary source. It does not independently establish truth. Follow EDITORIAL-WORKFLOW.md for verification and corrections.

Feed data is fetched from this origin every five minutes while the page is visible. A reviewed visual newsletter is researched daily; a full unified edition and two-day digest are prepared every two days. There is no continuous crawler, streaming government feed, visitor login or independent backend writer. New data becomes available after publishing. A 72-hour warning flags stale research. A failed refresh retains the current view with an error message.

The brand hero is a lightweight CSS illustration. Each edition has its own downloadable editorial SVG poster. Artwork is explicitly separated from evidence. WhatsApp links carry the current origin and stable edition path; a local preview link should never be distributed as public. No message is sent automatically. SVG posters can be opened in a browser and saved/printed; native WhatsApp image uploads may require PNG/JPEG conversion by the publisher.

## Deploy through the existing Sites project

Use Sites get_site with the project_id in .openai/hosting.json. Confirm public access and retrieve a fresh source credential. Open/sync the existing repository with the Sites source helper, build, commit/push the exact source and package dist. Pass the returned project_id, commit_sha and archive to save_site_version, then deploy_site_version using the returned saved-version id. Poll only pending/building/publishing states. Report a live URL only after terminal success. Credentials belong in memory/stdin, never this repository. Preserve Site identity and all historical dated URLs. The existing domain name contains the former Diaspora Brief title; changing branding does not require changing its URL.

For another static host, upload dist as the document root. Ensure .html paths and directory index routes work. _headers declares CSP, no-referrer, nosniff and restrictive permissions for hosts supporting that convention; confirm actual response headers on your host. New pages also contain a CSP meta policy. Legacy archived pages preserve their original layout and may load remote media. Host logs and external destinations are outside this app's privacy controls.

## Scheduling coordination

The existing local automation african-diaspora-daily-brief is ACTIVE daily at 06:00. The current host timezone is America/Los_Angeles, so its local schedule follows Pacific daylight saving. Check Scheduled for the exact next run. Keep the computer on and app running for this local task. If the system timezone changes, recheck timing. The supplied shared-chat URL is a historical snapshot, not a verified live data feed; the task uses its saved editorial instructions for daily research when the original tracker is inaccessible.

The original ChatGPT schedules tied to “KnowYourRights Africa — U.S. Immigrant Brief” and “Track Immigration Policy Alerts” are not available through this local automation tool. In ChatGPT Scheduled, pause those two legacy producers once the unified schedule is confirmed. Do not delete their chats or historical editions. Do not claim full scheduling consolidation until both pauses are confirmed. The Policy Alerts history said its check was hourly, so reconciling it matters. Manage tasks in Scheduled: https://learn.chatgpt.com/docs/automations.

## Validation

Build/data validation and JavaScript syntax checks pass. Browser checks cover archive search and no-result state, policy filtering, text-only toggle, source display and direct dated edition navigation. Mobile overflow and final publication status are checked during delivery. This is not a formal WCAG audit. Keyboard focus styles, native form labels, skip link, semantic headings and no-motion layout are included.
